from django.apps import AppConfig


class AppartmentsConfig(AppConfig):
    name = 'appartments'
